a <- read.csv('C:/Users/SARANG/Desktop/DOCS/Study/Spring
              /Predictive Analytics/Assignment 2/store A.csv')
library(dplyr)
library(broom)
a_selective <- a %>%
  select(-c(Store.Name,Code,X..of.Items,Date,Year,
            Distance.from.Station.X.Feet.,Distance.from.Station.Y.Feet.,
            Distance.from.Main.Street.Feet.,ActualHighTemp,
            Avg.Sales.per.Customer,Avg.Sales.per.Item))
a_selective <- scale(a_selective)
model_a <- lm(Total.Sales ~ ., a_selective)
tidy(model_a)

b <- read.csv('C:/Users/SARANG/Desktop/DOCS/Study/Spring/Predictive Analytics/Assignment 2/store B.csv')
b_selective <- b %>%
  select(-c(Store.Name,Code,X..of.Items,Date,Year,
            Distance.from.Station.X.Feet.,Distance.from.Station.Y.Feet.,
            Distance.from.Main.Street.Feet.,ActualHighTemp,Avg.Sales.per.Customer,Avg.Sales.per.Item))
model_b <- lm(Total.Sales ~ ., b_selective)
tidy(model_b)

c <- read.csv('C:/Users/SARANG/Desktop/DOCS/Study/Spring/
              Predictive Analytics/Assignment 2/store C.csv')
c_selective <- c %>%
  select(-c(Store.Name,Code,X..of.Items,Date,Year,
            Distance.from.Station.X.Feet.,Distance.from.Station.Y.Feet.,
            Distance.from.Main.Street.Feet.,ActualHighTemp,
            Avg.Sales.per.Customer,Avg.Sales.per.Item))
model_c <- lm(Total.Sales ~ ., c_selective)
tidy(model_c)

d <- read.csv('C:/Users/SARANG/Desktop/DOCS/Study/Spring/Predictive Analytics/Assignment 2/store D.csv')
d_selective <- d %>%
  select(-c(Store.Name,Code,X..of.Items,Date,Year,
            Distance.from.Station.X.Feet.,Distance.from.Station.Y.Feet.,
            Distance.from.Main.Street.Feet.,ActualHighTemp,Avg.Sales.per.Customer,Avg.Sales.per.Item))
model_d <- lm(Total.Sales ~ ., d_selective)
tidy(model_d)

e <- read.csv('C:/Users/SARANG/Desktop/DOCS/Study/Spring/Predictive Analytics/Assignment 2/store E.csv')
e_selective <- e %>%
  select(-c(Store.Name,Code,X..of.Items,Date,Year,
            Distance.from.Station.X.Feet.,Distance.from.Station.Y.Feet.,
            Distance.from.Main.Street.Feet.,ActualHighTemp,Avg.Sales.per.Customer,Avg.Sales.per.Item))
model_e <- lm(Total.Sales ~ ., e_selective)
tidy(model_e)
colnames(e_selective)
